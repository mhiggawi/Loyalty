# Comprehensive Loyalty System - Phase 1 MVP

A multi-tenant SaaS loyalty platform for retail businesses (restaurants, salons, shops, gyms, etc.)

## System Requirements

### Backend Requirements
- PHP 8.2 or higher (Laravel 11 requirement)
- Composer 2.x
- MySQL 8.0+
- Redis (for caching & queues)
- Node.js 18+ & npm (for asset compilation)

### Current Environment
- PHP: 8.0.30 (⚠️ Needs upgrade to 8.2+)
- Composer: 2.8.11 ✅

## Tech Stack

### Backend
- Laravel 11
- Filament 3 (Admin Panels)
- Laravel Sanctum (API Authentication)
- Stancl/Tenancy (Multi-tenancy)

### Frontend (Dashboards)
- Laravel Filament 3
- Tailwind CSS
- Alpine.js

### Mobile App
- React Native + Expo
- React Navigation
- Expo Camera (QR Scanner)
- Firebase Cloud Messaging

### Third-party Services
- Stripe (Subscriptions)
- Firebase (Push Notifications)
- SendGrid (Email)

## Project Structure

```
loyalty-system/
├── backend/                    # Laravel 11 Backend
│   ├── app/
│   │   ├── Models/            # Eloquent Models
│   │   ├── Http/
│   │   │   ├── Controllers/   # API & Web Controllers
│   │   │   ├── Middleware/    # Tenant isolation, Auth
│   │   │   └── Resources/     # API Resources
│   │   ├── Filament/          # Admin Panels
│   │   │   ├── SuperAdmin/    # Super Admin Panel
│   │   │   ├── Merchant/      # Merchant Dashboard
│   │   │   └── Staff/         # Staff Panel
│   │   ├── Services/          # Business Logic
│   │   └── Observers/         # Model Observers
│   ├── database/
│   │   ├── migrations/        # Database Migrations
│   │   └── seeders/           # Seed Data
│   ├── routes/
│   │   ├── api.php           # API Routes
│   │   ├── web.php           # Web Routes
│   │   └── tenant.php        # Tenant-specific Routes
│   └── config/
├── mobile/                    # React Native App
│   ├── src/
│   │   ├── screens/
│   │   ├── components/
│   │   ├── navigation/
│   │   ├── services/
│   │   └── utils/
│   └── assets/
└── docs/                      # Documentation
    ├── API.md
    ├── DATABASE.md
    └── DEPLOYMENT.md
```

## Design Philosophy

### Color Scheme
- **Default Mode**: Pure White (#FFFFFF)
- **Dark Mode**: Full dark mode toggle capability
- **Primary Color**: Purple (#667eea → #764ba2)
- **Success**: Green (#10b981)
- **Warning**: Yellow (#f59e0b)
- **Danger**: Red (#ef4444)

### Design Principles
- ✅ Modern, Professional, Minimalist
- ✅ Icons only (no stock photos)
- ✅ Clean typography
- ✅ Perfect alignment and spacing
- ✅ Zero visual clutter

### Typography
- Arabic: Cairo
- English: Inter

## Database Schema

### Core Tables (10 tables)
1. `tenants` - Merchant/business accounts
2. `global_customers` - All customers across platform
3. `customer_memberships` - Customer-merchant relationships
4. `transactions` - Points transactions (earn/redeem)
5. `rewards` - Merchant rewards catalog
6. `redemptions` - Reward redemption records
7. `tiers` - VIP tier definitions (Bronze/Silver/Gold/Platinum)
8. `staff` - Merchant staff members
9. `notifications` - Push/email notifications
10. `points_settings` - Per-merchant points configuration

## Installation (After PHP 8.2+ is installed)

### Backend Setup
```bash
cd backend
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
php artisan tenants:install
php artisan filament:install --panels=super_admin,merchant,staff
php artisan serve
```

### Mobile App Setup
```bash
cd mobile
npm install
npx expo start
```

## Multi-tenancy Architecture

Each merchant gets:
- Unique subdomain: `merchant-name.yourdomain.com`
- Isolated database records (tenant_id in all tables)
- Separate Filament panel: Merchant Dashboard
- Custom branding (logo, colors)

## Phase 1 MVP Features

### ✅ Core Features
- [x] Multi-tenant registration & isolation
- [x] Subscription system (Free Trial, Starter, Pro, Enterprise)
- [x] Points system (customizable: 1 JOD = X points)
- [x] 4-tier VIP system (Bronze/Silver/Gold/Platinum)
- [x] Rewards catalog & redemption
- [x] QR Code generation & scanning
- [x] Push notifications (Firebase)
- [x] Email notifications (SendGrid)
- [x] Super Admin dashboard
- [x] Merchant dashboard
- [x] Staff panel
- [x] Mobile app (React Native)

## API Endpoints

### Authentication
- `POST /api/auth/send-otp`
- `POST /api/auth/verify-otp`
- `POST /api/auth/login`
- `POST /api/auth/logout`

### Customer
- `GET /api/customer/profile`
- `GET /api/customer/memberships`
- `GET /api/customer/transactions`
- `GET /api/customer/notifications`

### Rewards
- `GET /api/rewards/{tenant_id}`
- `POST /api/rewards/redeem`
- `GET /api/redemptions`

### QR Code
- `GET /api/qrcode/generate`

## Security

- HTTPS mandatory (SSL Certificate)
- Password encryption (bcrypt)
- JWT for API authentication
- Session-based for dashboards
- OTP for mobile app
- Rate limiting: 100 requests/minute per merchant
- Role-based Access Control (RBAC)

## Development Timeline

### Phase 1 (MVP) - 10-12 weeks
- Week 1-2: Environment + Database
- Week 3-4: Multi-tenancy + Auth
- Week 5-6: Points & Tiers
- Week 7-8: Rewards & Redemption
- Week 9-10: Mobile App
- Week 11: Dashboards
- Week 12: Testing & Refinement

## Subscription Plans

| Plan | Price/Month | Max Customers | Max Staff | Features |
|------|-------------|---------------|-----------|----------|
| Free Trial | 0 JOD | 50 | 2 | 14 days, basic features |
| Starter | 49 JOD | 500 | 3 | Core features |
| Professional | 99 JOD | 2000 | 10 | + Analytics, SMS |
| Enterprise | 199 JOD | Unlimited | Unlimited | + API, Priority support |

## Support & Documentation

- API Documentation: Postman Collection
- Developer Guide: `/docs/DEVELOPMENT.md`
- Deployment Guide: `/docs/DEPLOYMENT.md`
- Database Schema: `/docs/DATABASE.md`

## License

Proprietary - All rights reserved

## Contact

For development inquiries or support, please contact the development team.

---

**Version**: 1.0
**Status**: In Development (Phase 1 MVP)
**Last Updated**: November 2024
