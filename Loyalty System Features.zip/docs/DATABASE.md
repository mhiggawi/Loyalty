# Database Schema Documentation

## Overview

This document describes the complete database schema for the Loyalty System Phase 1 MVP.

## Architecture

- **Multi-tenant**: Each table (except `global_customers`) has a `tenant_id` foreign key
- **Data Isolation**: All queries must filter by `tenant_id` to ensure data isolation
- **Soft Deletes**: Most tables use soft deletes for data recovery
- **Indexes**: Critical fields are indexed for query performance

## Entity Relationship Diagram (ERD)

```
┌─────────────┐
│   tenants   │
│  (Merchants)│
└──────┬──────┘
       │
       │ 1:N
       │
       ├─────────────┐
       │             │
       ▼             ▼
┌─────────────┐  ┌──────────────────┐
│points_settings│ │customer_memberships│◄──────┐
└─────────────┘  └────────┬───────────┘       │
                          │                    │
                          │ N:1                │ N:1
                          │                    │
┌─────────────┐           ▼                    │
│    tiers    │    ┌─────────────┐    ┌───────────────┐
└─────────────┘    │transactions │    │global_customers│
                   └─────────────┘    └───────────────┘
┌─────────────┐
│   rewards   │
└──────┬──────┘
       │
       │ 1:N
       │
       ▼
┌─────────────┐
│ redemptions │
└─────────────┘

┌─────────────┐
│    staff    │
└─────────────┘

┌─────────────────┐
│ notifications   │
└─────────────────┘
```

## Tables

### 1. tenants (Merchants)

Stores information about each merchant/business subscribed to the platform.

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| business_name | VARCHAR(255) | Business name |
| business_slug | VARCHAR(100) | Unique slug for subdomain |
| business_type | ENUM | Type: restaurant, salon, retail, gym, cafe, other |
| email | VARCHAR(255) | Business email (unique) |
| phone | VARCHAR(20) | Contact phone |
| logo_url | VARCHAR(500) | Logo image URL |
| primary_color | VARCHAR(7) | Hex color for branding |
| subscription_plan | ENUM | free_trial, starter, professional, enterprise |
| subscription_status | ENUM | trial, active, suspended, cancelled |
| subscription_expires_at | DATETIME | Subscription expiry date |
| max_customers | INT | Max customers allowed (plan-based) |
| max_staff | INT | Max staff allowed (plan-based) |
| trial_ends_at | DATETIME | Trial period end date |
| api_key | VARCHAR(100) | Unique API key for POS integration |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |
| deleted_at | TIMESTAMP | Soft delete timestamp |

**Indexes:**
- `business_slug` (unique)
- `email` (unique)
- `api_key` (unique)
- `subscription_status`

---

### 2. global_customers

Platform-wide customer database. One customer can have multiple memberships across different merchants.

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| phone_number | VARCHAR(20) | Phone (unique, primary identifier) |
| email | VARCHAR(255) | Email (unique, nullable) |
| full_name | VARCHAR(255) | Customer full name |
| date_of_birth | DATE | Date of birth (for birthday rewards) |
| password_hash | VARCHAR(255) | Hashed password |
| device_token | VARCHAR(500) | FCM device token for push notifications |
| language | ENUM | ar, en (default: ar) |
| email_verified_at | TIMESTAMP | Email verification timestamp |
| phone_verified_at | TIMESTAMP | Phone verification timestamp |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |
| deleted_at | TIMESTAMP | Soft delete timestamp |

**Indexes:**
- `phone_number` (unique)
- `email` (unique)

---

### 3. customer_memberships

Links customers to merchants. Stores customer-specific data per merchant.

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| global_customer_id | BIGINT | FK to global_customers |
| tenant_id | BIGINT | FK to tenants |
| current_points | INT | Current points balance |
| total_points_earned | INT | Lifetime points earned |
| total_points_redeemed | INT | Lifetime points redeemed |
| total_visits | INT | Number of visits/transactions |
| total_spent | DECIMAL(10,2) | Total amount spent |
| tier_level | ENUM | bronze, silver, gold, platinum |
| tier_upgraded_at | TIMESTAMP | Last tier upgrade date |
| membership_status | ENUM | active, suspended, blocked |
| qr_code_hash | VARCHAR(100) | Unique QR code identifier |
| joined_at | TIMESTAMP | Membership creation date |
| last_visit_at | TIMESTAMP | Last visit/transaction date |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |
| deleted_at | TIMESTAMP | Soft delete timestamp |

**Unique Constraint:**
- `(global_customer_id, tenant_id)` - One membership per customer per merchant

**Indexes:**
- `tenant_id`
- `tier_level`
- `membership_status`
- `qr_code_hash` (unique)

---

### 4. points_settings

Per-merchant configuration for points system.

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| tenant_id | BIGINT | FK to tenants (unique) |
| currency_to_points_ratio | DECIMAL(10,2) | 1 JOD = X points |
| points_expiry_months | INT | Points expire after X months (NULL = never) |
| allow_partial_redemption | BOOLEAN | Allow partial points redemption |
| min_points_for_redemption | INT | Minimum points required to redeem |
| welcome_bonus_points | INT | Bonus points on sign-up |
| birthday_bonus_points | INT | Bonus points on birthday |
| referrer_bonus_points | INT | Points for referrer |
| referee_bonus_points | INT | Points for referred customer |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |

**Index:**
- `tenant_id` (unique)

---

### 5. tiers

VIP tier definitions (Bronze, Silver, Gold, Platinum) per merchant.

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| tenant_id | BIGINT | FK to tenants |
| name | VARCHAR(100) | Tier name (e.g., "Bronze") |
| level | ENUM | bronze, silver, gold, platinum |
| min_points | INT | Minimum points to reach this tier |
| points_multiplier | DECIMAL(3,2) | Points multiplier (1.00 = 1x) |
| benefits | TEXT | Description of tier benefits |
| icon | VARCHAR(50) | Emoji or icon name |
| color | VARCHAR(7) | Hex color code |
| display_order | INT | Sort order |
| is_active | BOOLEAN | Is tier active? |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |

**Unique Constraint:**
- `(tenant_id, level)` - One tier per level per merchant

**Indexes:**
- `tenant_id`
- `level`
- `min_points`

---

### 6. transactions

Complete history of all points transactions (earn, redeem, bonus, etc.).

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| tenant_id | BIGINT | FK to tenants |
| customer_membership_id | BIGINT | FK to customer_memberships |
| type | ENUM | earn, redeem, bonus, referral, manual_add, manual_subtract, expire, adjustment |
| points | INT | Points amount (positive or negative) |
| amount | DECIMAL(10,2) | Purchase amount (for earn type) |
| description | VARCHAR(500) | Transaction description |
| reference_id | BIGINT | Related record ID (reward_id, redemption_id) |
| reference_type | VARCHAR(50) | Related record type |
| staff_id | BIGINT | FK to staff (for manual transactions) |
| balance_after | INT | Points balance after transaction |
| metadata | JSON | Additional data |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |

**Indexes:**
- `tenant_id`
- `customer_membership_id`
- `type`
- `created_at`
- `(reference_type, reference_id)`

---

### 7. rewards

Merchant rewards catalog.

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| tenant_id | BIGINT | FK to tenants |
| title_ar | VARCHAR(255) | Arabic title |
| title_en | VARCHAR(255) | English title |
| description_ar | TEXT | Arabic description |
| description_en | TEXT | English description |
| image_url | VARCHAR(500) | Reward image URL |
| category | ENUM | drink, food, discount, gift, experience, service, other |
| reward_type | ENUM | free_product, percentage_discount, fixed_discount, experience |
| discount_value | DECIMAL(10,2) | Discount value (for discount types) |
| points_required | INT | Points needed to redeem |
| stock | INT | Available quantity (NULL = unlimited) |
| is_active | BOOLEAN | Is reward active? |
| display_order | INT | Sort order |
| min_tier_required | ENUM | Minimum tier required (NULL = all) |
| terms_ar | TEXT | Arabic terms and conditions |
| terms_en | TEXT | English terms and conditions |
| valid_from | DATETIME | Valid from date |
| valid_until | DATETIME | Valid until date |
| total_redemptions | INT | Total redemption count |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |
| deleted_at | TIMESTAMP | Soft delete timestamp |

**Indexes:**
- `tenant_id`
- `category`
- `reward_type`
- `is_active`
- `points_required`

---

### 8. redemptions

Reward redemption records.

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| tenant_id | BIGINT | FK to tenants |
| customer_membership_id | BIGINT | FK to customer_memberships |
| reward_id | BIGINT | FK to rewards |
| points_used | INT | Points deducted |
| status | ENUM | pending, approved, rejected, used, expired, cancelled |
| redemption_code | VARCHAR(20) | Unique redemption code |
| qr_code_hash | VARCHAR(100) | QR code for verification |
| redeemed_at | TIMESTAMP | Redemption request timestamp |
| approved_at | TIMESTAMP | Approval timestamp |
| used_at | TIMESTAMP | Usage timestamp |
| expires_at | TIMESTAMP | Expiry timestamp |
| approved_by | BIGINT | FK to staff |
| used_by | BIGINT | FK to staff |
| notes | TEXT | Notes (rejection reason, etc.) |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |
| deleted_at | TIMESTAMP | Soft delete timestamp |

**Indexes:**
- `tenant_id`
- `customer_membership_id`
- `reward_id`
- `status`
- `redemption_code` (unique)
- `redeemed_at`

---

### 9. staff

Merchant staff members (admin, manager, staff roles).

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| tenant_id | BIGINT | FK to tenants |
| branch_id | BIGINT | FK to branches (Phase 2) |
| full_name | VARCHAR(255) | Staff full name |
| email | VARCHAR(255) | Email (unique) |
| phone | VARCHAR(20) | Phone number |
| password_hash | VARCHAR(255) | Hashed password |
| role | ENUM | admin, manager, staff |
| permissions | JSON | Granular permissions |
| profile_image_url | VARCHAR(500) | Profile image URL |
| is_active | BOOLEAN | Is staff active? |
| last_login_at | TIMESTAMP | Last login timestamp |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |
| deleted_at | TIMESTAMP | Soft delete timestamp |

**Indexes:**
- `tenant_id`
- `role`
- `is_active`
- `email` (unique)

---

### 10. notifications

Customer notifications (push, email, SMS).

| Column | Type | Description |
|--------|------|-------------|
| id | BIGINT | Primary key |
| tenant_id | BIGINT | FK to tenants |
| customer_membership_id | BIGINT | FK to customer_memberships (nullable for broadcasts) |
| type | ENUM | points_earned, tier_upgrade, reward_available, points_expiring, redemption_approved, redemption_rejected, birthday, anniversary, custom |
| title_ar | VARCHAR(255) | Arabic title |
| title_en | VARCHAR(255) | English title |
| message_ar | TEXT | Arabic message |
| message_en | TEXT | English message |
| action_data | JSON | Deep link data |
| is_read | BOOLEAN | Has customer read it? |
| sent_push | BOOLEAN | Sent via push? |
| sent_email | BOOLEAN | Sent via email? |
| sent_sms | BOOLEAN | Sent via SMS? |
| priority | ENUM | low, normal, high |
| scheduled_at | TIMESTAMP | Scheduled send time |
| sent_at | TIMESTAMP | Actual send time |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update timestamp |
| deleted_at | TIMESTAMP | Soft delete timestamp |

**Indexes:**
- `tenant_id`
- `customer_membership_id`
- `type`
- `is_read`
- `sent_at`
- `scheduled_at`

---

## Sample Data Flow

### 1. Customer Earns Points

```sql
-- Customer makes a purchase of 50 JOD
-- Points setting: 1 JOD = 10 points
-- Customer tier: Silver (1.5x multiplier)

-- Calculate points
Base points = 50 * 10 = 500
Tier bonus = 500 * 1.5 = 750 total points

-- Insert transaction
INSERT INTO transactions (
    tenant_id, customer_membership_id, type, points, amount, description, balance_after
) VALUES (
    1, 100, 'earn', 750, 50.00, 'Purchase: 50 JOD', 1250
);

-- Update membership
UPDATE customer_memberships
SET current_points = current_points + 750,
    total_points_earned = total_points_earned + 750,
    total_visits = total_visits + 1,
    total_spent = total_spent + 50.00,
    last_visit_at = NOW()
WHERE id = 100;

-- Create notification
INSERT INTO notifications (
    tenant_id, customer_membership_id, type, title_en, message_en, sent_push
) VALUES (
    1, 100, 'points_earned', 'Points Earned!', 'You earned 750 points!', true
);
```

### 2. Customer Redeems Reward

```sql
-- Customer wants to redeem "Free Coffee" (100 points)

-- Insert redemption
INSERT INTO redemptions (
    tenant_id, customer_membership_id, reward_id, points_used, status, redemption_code
) VALUES (
    1, 100, 5, 100, 'approved', 'RDM-ABC123'
);

-- Insert transaction
INSERT INTO transactions (
    tenant_id, customer_membership_id, type, points, description, reference_id, reference_type, balance_after
) VALUES (
    1, 100, 'redeem', -100, 'Redeemed: Free Coffee', 5, 'reward', 1150
);

-- Update membership
UPDATE customer_memberships
SET current_points = current_points - 100,
    total_points_redeemed = total_points_redeemed + 100
WHERE id = 100;

-- Update reward stats
UPDATE rewards
SET total_redemptions = total_redemptions + 1,
    stock = stock - 1
WHERE id = 5;
```

### 3. Auto Tier Upgrade

```sql
-- After earning points, check if customer qualifies for tier upgrade
-- Current: Silver (min 501 points)
-- New balance: 1550 points -> Gold tier (min 1501 points)

UPDATE customer_memberships
SET tier_level = 'gold',
    tier_upgraded_at = NOW()
WHERE id = 100;

-- Create notification
INSERT INTO notifications (
    tenant_id, customer_membership_id, type, title_en, message_en, sent_push
) VALUES (
    1, 100, 'tier_upgrade', 'Tier Upgrade!', 'Congratulations! You are now Gold tier!', true
);
```

---

## Best Practices

### 1. Always Filter by tenant_id

```sql
-- ❌ BAD: No tenant filter
SELECT * FROM rewards WHERE is_active = true;

-- ✅ GOOD: Filtered by tenant
SELECT * FROM rewards WHERE tenant_id = 1 AND is_active = true;
```

### 2. Use Transactions

```sql
-- When earning/redeeming points, wrap in transaction
START TRANSACTION;

-- Update points
UPDATE customer_memberships SET current_points = ...;

-- Insert transaction record
INSERT INTO transactions ...;

-- Create notification
INSERT INTO notifications ...;

COMMIT;
```

### 3. Index Foreign Keys

All foreign keys are indexed for query performance.

### 4. Soft Deletes

Use soft deletes to maintain data integrity and allow recovery.

```sql
-- Don't permanently delete
DELETE FROM rewards WHERE id = 5;

-- Use soft delete instead
UPDATE rewards SET deleted_at = NOW() WHERE id = 5;
```

---

## Migration Order

Migrations must be run in this order due to foreign key dependencies:

1. `001_create_tenants_table`
2. `002_create_global_customers_table`
3. `003_create_customer_memberships_table`
4. `004_create_points_settings_table`
5. `005_create_tiers_table`
6. `006_create_transactions_table`
7. `007_create_rewards_table`
8. `008_create_redemptions_table`
9. `009_create_staff_table`
10. `010_create_notifications_table`

---

## Performance Considerations

- All tables have proper indexes on frequently queried columns
- `tenant_id` is indexed in all multi-tenant tables
- Composite unique constraints prevent duplicate memberships
- Transaction table is optimized for time-based queries
- Consider partitioning `transactions` table when volume exceeds 10M records

---

**Last Updated:** November 2024
**Version:** 1.0
