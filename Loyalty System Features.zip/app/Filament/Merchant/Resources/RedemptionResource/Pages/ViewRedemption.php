<?php

namespace App\Filament\Merchant\Resources\RedemptionResource\Pages;

use App\Filament\Merchant\Resources\RedemptionResource;
use Filament\Resources\Pages\ViewRecord;

class ViewRedemption extends ViewRecord
{
    protected static string $resource = RedemptionResource::class;
}
