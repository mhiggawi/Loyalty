<?php

namespace App\Filament\Merchant\Resources\TransactionResource\Pages;

use App\Filament\Merchant\Resources\TransactionResource;
use Filament\Resources\Pages\ViewRecord;

class ViewTransaction extends ViewRecord
{
    protected static string $resource = TransactionResource::class;
}
