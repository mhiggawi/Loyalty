<?php

namespace App\Filament\Merchant\Resources\CustomerMembershipResource\Pages;

use App\Filament\Merchant\Resources\CustomerMembershipResource;
use Filament\Resources\Pages\ViewRecord;

class ViewCustomerMembership extends ViewRecord
{
    protected static string $resource = CustomerMembershipResource::class;
}
