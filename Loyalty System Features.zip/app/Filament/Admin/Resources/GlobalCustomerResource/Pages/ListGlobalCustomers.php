<?php

namespace App\Filament\Admin\Resources\GlobalCustomerResource\Pages;

use App\Filament\Admin\Resources\GlobalCustomerResource;
use Filament\Resources\Pages\ListRecords;

class ListGlobalCustomers extends ListRecords
{
    protected static string $resource = GlobalCustomerResource::class;
}
