<?php

namespace App\Filament\Admin\Resources\GlobalCustomerResource\Pages;

use App\Filament\Admin\Resources\GlobalCustomerResource;
use Filament\Resources\Pages\ViewRecord;

class ViewGlobalCustomer extends ViewRecord
{
    protected static string $resource = GlobalCustomerResource::class;
}
