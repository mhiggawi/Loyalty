# Loyalty App - React Native Mobile Application

**Customer-facing mobile application for the Loyalty System**

Built with React Native, Expo, and TypeScript

---

## Features

### Core Functionality

✅ **OTP Authentication** - Secure phone number verification
✅ **Multi-Merchant Support** - Manage memberships across multiple merchants
✅ **QR Code Display** - Unique QR codes for each merchant membership
✅ **Points & Tier Tracking** - Real-time points balance and tier progress
✅ **Rewards Catalog** - Browse and redeem available rewards
✅ **Transaction History** - View all points earning and redemption transactions
✅ **Dark Mode** - Pure White default with Dark Mode toggle
✅ **Secure Token Storage** - Expo SecureStore for JWT tokens
✅ **API Integration** - Complete integration with all 31 backend endpoints

---

## Tech Stack

- **React Native** 0.73.0
- **Expo** ~50.0.0
- **TypeScript** 5.1.3
- **React Navigation** 6.x (Native Stack & Bottom Tabs)
- **Axios** - API requests
- **Expo SecureStore** - Secure token storage
- **react-native-qrcode-svg** - QR code generation
- **expo-linear-gradient** - Gradient UI elements

---

## Project Structure

```
mobile-app/
├── src/
│   ├── contexts/          # React Context providers
│   │   ├── AuthContext.tsx       # Authentication state management
│   │   └── ThemeContext.tsx      # Theme & Dark Mode management
│   ├── navigation/        # Navigation configuration
│   │   ├── AuthNavigator.tsx     # Authentication flow
│   │   └── MainNavigator.tsx     # Main app bottom tabs
│   ├── screens/           # Screen components
│   │   ├── auth/
│   │   │   ├── WelcomeScreen.tsx
│   │   │   ├── PhoneInputScreen.tsx
│   │   │   └── OtpVerificationScreen.tsx
│   │   ├── main/
│   │   │   ├── HomeScreen.tsx
│   │   │   ├── RewardsScreen.tsx
│   │   │   ├── TransactionsScreen.tsx
│   │   │   └── ProfileScreen.tsx
│   │   └── LoadingScreen.tsx
│   └── services/          # External services
│       └── api.ts                # API service layer
├── App.tsx                # Root component
├── app.json               # Expo configuration
├── package.json           # Dependencies
└── tsconfig.json          # TypeScript configuration
```

---

## Installation

### Prerequisites

- Node.js 18+ and npm/yarn
- Expo CLI (`npm install -g expo-cli`)
- iOS Simulator (Mac) or Android Studio (for testing)
- Expo Go app on your phone (for testing on physical device)

### Setup Steps

1. **Navigate to mobile-app directory:**
   ```bash
   cd mobile-app
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Configure API URL:**
   ```bash
   cp .env.example .env
   ```

   Edit `.env` and set your API URL:
   ```
   API_URL=http://your-api-url.com/api
   ```

4. **Start the development server:**
   ```bash
   npm start
   ```

5. **Run on simulator/device:**
   - Press `i` for iOS simulator
   - Press `a` for Android emulator
   - Scan QR code with Expo Go app on physical device

---

## Configuration

### API URL Configuration

The API URL is configured in `app.config.js`:

```javascript
extra: {
  apiUrl: process.env.API_URL || 'http://localhost:8000/api',
}
```

For development on physical device, use your computer's local IP:
```
API_URL=http://192.168.1.100:8000/api
```

For production:
```
API_URL=https://api.yourdomain.com/api
```

---

## Theme System

### Pure White Default Theme

The app uses a **Pure White (#FFFFFF)** default theme with a visible **Dark Mode toggle** in the Profile screen.

### Theme Colors

**Light Mode:**
- Background: `#FFFFFF` (Pure White)
- Primary: `#8B5CF6` (Purple)
- Success: `#10B981`
- Danger: `#EF4444`

**Dark Mode:**
- Background: `#0F0F0F`
- Surface: `#1A1A1A`
- Primary: `#A78BFA`

### Toggling Dark Mode

Users can toggle dark mode in:
1. Profile screen → Preferences section
2. Home screen header (moon/sun icon)

Theme preference is persisted in AsyncStorage.

---

## Authentication Flow

### OTP-Based Authentication

1. **Welcome Screen** - User sees app introduction
2. **Phone Input Screen** - User enters phone number
3. **OTP Verification Screen** - User enters 6-digit OTP
4. **Auto-Login** - Token stored securely, user logged in

### Secure Token Storage

- JWT tokens stored using **Expo SecureStore**
- Encrypted storage on device
- Automatic token refresh on app launch
- Tokens included in all API requests via Axios interceptor

---

## API Integration

### API Service Layer

The `api.ts` service provides typed methods for all API endpoints:

```typescript
// Authentication
apiService.sendOtp(phoneNumber)
apiService.verifyOtp(phoneNumber, otp)
apiService.getProfile()
apiService.logout()

// Memberships
apiService.getMemberships()
apiService.getMembershipPoints(tenantSlug)
apiService.joinMerchant(tenantSlug)

// Rewards
apiService.getRewards(tenantSlug)
apiService.redeemReward(tenantSlug, rewardId)

// Transactions
apiService.getTransactions(tenantSlug)
apiService.getTransactionStats(tenantSlug)

// QR Codes
apiService.getQRCode(tenantSlug)
```

### Request/Response Handling

- Automatic Bearer token injection
- Centralized error handling
- 30-second request timeout
- JSON-only requests

---

## Screens Overview

### Authentication Screens

#### WelcomeScreen
- App introduction with feature highlights
- Clean gradient design
- Get Started CTA button

#### PhoneInputScreen
- Phone number input with country code (+962)
- Input validation and formatting
- Send OTP API integration

#### OtpVerificationScreen
- 6-digit OTP input with auto-focus
- 60-second countdown timer
- Resend OTP functionality
- Auto-submit when complete

### Main Screens

#### HomeScreen (Tab 1)
- **QR Code Display** - Scannable QR code for current merchant
- **Points Summary** - Current points, lifetime points, tier badge
- **Merchant Selector** - Switch between memberships
- **Quick Actions** - Shortcuts to other features
- **Dark Mode Toggle** - Sun/moon icon in header
- **Pull-to-Refresh** - Reload data

#### RewardsScreen (Tab 2)
- **Rewards Catalog** - Browse all available rewards
- **Eligibility Indicators** - Shows if user can redeem
- **Points Requirements** - Clear display of points needed
- **Tier Requirements** - Tier restrictions shown
- **One-Tap Redemption** - Redeem with confirmation
- **Redemption Codes** - Display unique redemption codes

#### TransactionsScreen (Tab 3)
- **Transaction List** - All points movements
- **Statistics Summary** - Total earned, redeemed, current balance
- **Transaction Icons** - Visual indicators for transaction types
- **Date Formatting** - Human-readable relative dates
- **Merchant Filter** - Filter by merchant

#### ProfileScreen (Tab 4)
- **User Profile** - Name, phone, email display
- **Dark Mode Toggle** - Prominent switch control
- **Notifications Toggle** - Enable/disable notifications
- **Language Selector** - Arabic/English (placeholder)
- **Account Management** - Edit profile, memberships, QR codes
- **Support Links** - Help center, contact us
- **Logout** - Secure logout with confirmation

---

## State Management

### AuthContext

Manages authentication state globally:
- `isAuthenticated` - Boolean auth status
- `customer` - Customer data
- `token` - JWT token
- `login()` - Save auth data
- `logout()` - Clear auth data
- `updateCustomer()` - Update customer info

### ThemeContext

Manages theme state globally:
- `isDarkMode` - Boolean dark mode status
- `colors` - Theme color palette
- `toggleTheme()` - Switch between light/dark

---

## Security Features

✅ **Secure Token Storage** - Expo SecureStore (encrypted)
✅ **Automatic Token Refresh** - Validates token on app launch
✅ **HTTPS Only** - All API requests over HTTPS (production)
✅ **Request Timeout** - 30-second timeout prevents hanging
✅ **Error Handling** - Graceful error messages
✅ **Rate Limiting** - Respects API rate limits

---

## Development

### Running the App

```bash
# Start Expo dev server
npm start

# Run on iOS simulator
npm run ios

# Run on Android emulator
npm run android

# Run on web (limited functionality)
npm run web
```

### Code Style

The project uses TypeScript with strict mode enabled:
- Type-safe API responses
- Proper interface definitions
- No implicit `any` types

---

## Building for Production

### iOS (requires Mac)

1. Build with EAS Build:
   ```bash
   npm install -g eas-cli
   eas build --platform ios
   ```

2. Submit to App Store:
   ```bash
   eas submit --platform ios
   ```

### Android

1. Build APK/AAB:
   ```bash
   eas build --platform android
   ```

2. Submit to Google Play:
   ```bash
   eas submit --platform android
   ```

---

## Testing

### Manual Testing Checklist

**Authentication:**
- [ ] OTP sent successfully
- [ ] OTP verification works
- [ ] Invalid OTP shows error
- [ ] Resend OTP after 60 seconds
- [ ] Logout clears session

**Home Screen:**
- [ ] QR code displays correctly
- [ ] Points update after transaction
- [ ] Tier progress shows correctly
- [ ] Multi-merchant switching works
- [ ] Pull-to-refresh reloads data

**Rewards:**
- [ ] All rewards display
- [ ] Redemption eligibility accurate
- [ ] Redemption creates code
- [ ] Points deducted after redemption

**Transactions:**
- [ ] All transactions display
- [ ] Statistics accurate
- [ ] Transaction icons correct
- [ ] Date formatting readable

**Profile:**
- [ ] Dark mode toggle works
- [ ] Theme persists after app restart
- [ ] Logout works correctly

---

## Troubleshooting

### Common Issues

**1. API Connection Failed**
- Ensure API URL is correct in `.env`
- For physical device, use computer's local IP
- Check backend server is running

**2. QR Code Not Displaying**
- Check API response in network tab
- Verify membership exists
- Ensure QR code hash is present

**3. Dark Mode Not Persisting**
- AsyncStorage permissions may be blocked
- Try clearing app data and re-login

**4. Build Errors**
- Clear cache: `expo start -c`
- Delete node_modules: `rm -rf node_modules && npm install`

---

## Future Enhancements

### Phase 2 Features (Not Implemented)

- [ ] Notifications screen
- [ ] Push notifications (Firebase)
- [ ] Biometric authentication (Face ID/Touch ID)
- [ ] Offline mode with local caching
- [ ] Sharing rewards with friends
- [ ] Referral system
- [ ] Birthday bonus notifications
- [ ] Points expiration alerts
- [ ] In-app chat support
- [ ] Multi-language support (full Arabic)

---

## Performance Optimizations

✅ **Lazy Loading** - Screens loaded on-demand
✅ **Image Optimization** - Cached and optimized images
✅ **List Virtualization** - FlatList for efficient rendering
✅ **Memo Components** - Prevent unnecessary re-renders
✅ **Efficient State Updates** - Minimal re-renders

---

## Dependencies

### Core Dependencies
```json
{
  "expo": "~50.0.0",
  "react": "18.2.0",
  "react-native": "0.73.0",
  "@react-navigation/native": "^6.1.9",
  "@react-navigation/bottom-tabs": "^6.5.11",
  "@react-navigation/native-stack": "^6.9.17",
  "axios": "^1.6.2",
  "expo-secure-store": "~12.8.1",
  "react-native-qrcode-svg": "^6.3.0"
}
```

### Total Package Size
- ~200MB node_modules
- ~50MB app bundle (optimized)

---

## Support

For issues or questions:
- **Backend API Docs:** See `API_DOCUMENTATION.md`
- **GitHub Issues:** Report bugs and feature requests
- **Email:** support@loyalty-app.com

---

## License

Proprietary - All Rights Reserved

---

## Contributors

- **Backend:** Laravel 11 RESTful API
- **Mobile:** React Native + Expo
- **Design:** Pure White theme with Dark Mode

---

**Version:** 1.0.0
**Last Updated:** November 29, 2025
**Status:** Phase 1 MVP Complete ✅
