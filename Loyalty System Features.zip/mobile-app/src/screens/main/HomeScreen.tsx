import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import QRCode from 'react-native-qrcode-svg';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { apiService } from '../../services/api';

const { width } = Dimensions.get('window');

interface Membership {
  id: number;
  tenant: {
    id: number;
    business_name: string;
    business_slug: string;
    logo_url: string | null;
  };
  current_points: number;
  lifetime_points: number;
  tier: {
    level: string;
    name: string;
    icon: string;
    color: string;
    multiplier: number;
  };
  qr_code_hash: string;
}

export default function HomeScreen() {
  const { colors, isDarkMode, toggleTheme } = useTheme();
  const { customer } = useAuth();

  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [selectedMembership, setSelectedMembership] = useState<Membership | null>(null);
  const [qrCodeData, setQrCodeData] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    loadMemberships();
  }, []);

  const loadMemberships = async () => {
    try {
      const response = await apiService.getMemberships();

      if (response.success && response.data) {
        setMemberships(response.data.memberships);
        if (response.data.memberships.length > 0) {
          selectMembership(response.data.memberships[0]);
        }
      }
    } catch (error) {
      console.error('Error loading memberships:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const selectMembership = async (membership: Membership) => {
    setSelectedMembership(membership);

    try {
      const response = await apiService.getQRCode(membership.tenant.business_slug);
      if (response.success && response.data) {
        setQrCodeData(response.data.qr_code_data);
      }
    } catch (error) {
      console.error('Error loading QR code:', error);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadMemberships();
    setIsRefreshing(false);
  };

  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (memberships.length === 0) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.emptyState}>
          <Ionicons name="card-outline" size={80} color={colors.textSecondary} />
          <Text style={[styles.emptyTitle, { color: colors.text }]}>No Memberships Yet</Text>
          <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}>
            Join your favorite merchants to start earning rewards
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <LinearGradient
        colors={isDarkMode ? ['#1A1A1A', '#0F0F0F'] : ['#8B5CF6', '#A78BFA']}
        style={styles.header}
      >
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.greeting}>Hello,</Text>
            <Text style={styles.customerName}>{customer?.full_name || 'Customer'}</Text>
          </View>
          <TouchableOpacity onPress={toggleTheme} style={styles.themeToggle}>
            <Ionicons name={isDarkMode ? 'sunny' : 'moon'} size={24} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <ScrollView
        style={styles.content}
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={handleRefresh} />}
      >
        {/* Merchant Selector */}
        {memberships.length > 1 && (
          <View style={styles.merchantSelector}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Select Merchant</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.merchantList}>
              {memberships.map((membership) => (
                <TouchableOpacity
                  key={membership.id}
                  style={[
                    styles.merchantCard,
                    {
                      backgroundColor: colors.surface,
                      borderColor:
                        selectedMembership?.id === membership.id ? colors.primary : colors.border,
                    },
                  ]}
                  onPress={() => selectMembership(membership)}
                >
                  <Text style={[styles.merchantName, { color: colors.text }]}>
                    {membership.tenant.business_name}
                  </Text>
                  <Text style={[styles.merchantPoints, { color: colors.primary }]}>
                    {membership.current_points} pts
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {selectedMembership && (
          <>
            {/* QR Code Card */}
            <View style={[styles.qrCard, { backgroundColor: colors.card }]}>
              <Text style={[styles.qrTitle, { color: colors.text }]}>
                {selectedMembership.tenant.business_name}
              </Text>
              <Text style={[styles.qrSubtitle, { color: colors.textSecondary }]}>
                Show this QR code at checkout
              </Text>

              <View style={[styles.qrContainer, { backgroundColor: '#FFFFFF' }]}>
                {qrCodeData ? (
                  <QRCode value={qrCodeData} size={200} />
                ) : (
                  <ActivityIndicator size="large" color={colors.primary} />
                )}
              </View>

              <View style={styles.qrFooter}>
                <Ionicons name="shield-checkmark" size={16} color={colors.success} />
                <Text style={[styles.qrFooterText, { color: colors.textSecondary }]}>
                  Secure QR Code
                </Text>
              </View>
            </View>

            {/* Points Summary */}
            <View style={[styles.pointsCard, { backgroundColor: colors.card }]}>
              <View style={styles.pointsHeader}>
                <Text style={[styles.cardTitle, { color: colors.text }]}>Your Points</Text>
                <View style={[styles.tierBadge, { backgroundColor: selectedMembership.tier.color + '20' }]}>
                  <Text style={styles.tierIcon}>{selectedMembership.tier.icon}</Text>
                  <Text style={[styles.tierName, { color: selectedMembership.tier.color }]}>
                    {selectedMembership.tier.name}
                  </Text>
                </View>
              </View>

              <View style={styles.pointsRow}>
                <View style={styles.pointsItem}>
                  <Text style={[styles.pointsValue, { color: colors.primary }]}>
                    {selectedMembership.current_points.toLocaleString()}
                  </Text>
                  <Text style={[styles.pointsLabel, { color: colors.textSecondary }]}>
                    Current Points
                  </Text>
                </View>
                <View style={[styles.divider, { backgroundColor: colors.border }]} />
                <View style={styles.pointsItem}>
                  <Text style={[styles.pointsValue, { color: colors.text }]}>
                    {selectedMembership.lifetime_points.toLocaleString()}
                  </Text>
                  <Text style={[styles.pointsLabel, { color: colors.textSecondary }]}>
                    Lifetime Points
                  </Text>
                </View>
              </View>

              <View style={[styles.multiplierBadge, { backgroundColor: colors.surface }]}>
                <Ionicons name="trending-up" size={18} color={colors.success} />
                <Text style={[styles.multiplierText, { color: colors.text }]}>
                  {selectedMembership.tier.multiplier}x Points Multiplier
                </Text>
              </View>
            </View>

            {/* Quick Actions */}
            <View style={styles.quickActions}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>Quick Actions</Text>
              <View style={styles.actionsGrid}>
                <ActionButton
                  icon="gift"
                  label="Rewards"
                  colors={colors}
                  onPress={() => {}}
                />
                <ActionButton
                  icon="list"
                  label="History"
                  colors={colors}
                  onPress={() => {}}
                />
                <ActionButton
                  icon="trophy"
                  label="Tiers"
                  colors={colors}
                  onPress={() => {}}
                />
                <ActionButton
                  icon="notifications"
                  label="Alerts"
                  colors={colors}
                  onPress={() => {}}
                />
              </View>
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

interface ActionButtonProps {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  colors: any;
  onPress: () => void;
}

function ActionButton({ icon, label, colors, onPress }: ActionButtonProps) {
  return (
    <TouchableOpacity
      style={[styles.actionButton, { backgroundColor: colors.surface }]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.actionIcon, { backgroundColor: colors.primary + '20' }]}>
        <Ionicons name={icon} size={24} color={colors.primary} />
      </View>
      <Text style={[styles.actionLabel, { color: colors.text }]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 24,
    paddingBottom: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greeting: {
    fontSize: 16,
    color: '#FFFFFF',
    opacity: 0.9,
  },
  customerName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#FFFFFF',
    marginTop: 4,
  },
  themeToggle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  merchantSelector: {
    marginTop: 24,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
  },
  merchantList: {
    marginHorizontal: -24,
    paddingHorizontal: 24,
  },
  merchantCard: {
    padding: 16,
    borderRadius: 12,
    marginRight: 12,
    borderWidth: 2,
    minWidth: 140,
  },
  merchantName: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  merchantPoints: {
    fontSize: 14,
    fontWeight: '700',
  },
  qrCard: {
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginTop: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  qrTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  qrSubtitle: {
    fontSize: 14,
    marginBottom: 24,
  },
  qrContainer: {
    padding: 24,
    borderRadius: 16,
    marginBottom: 16,
  },
  qrFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  qrFooterText: {
    fontSize: 12,
    fontWeight: '500',
  },
  pointsCard: {
    borderRadius: 16,
    padding: 20,
    marginTop: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  pointsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
  },
  tierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  tierIcon: {
    fontSize: 16,
  },
  tierName: {
    fontSize: 14,
    fontWeight: '600',
  },
  pointsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  pointsItem: {
    flex: 1,
    alignItems: 'center',
  },
  pointsValue: {
    fontSize: 32,
    fontWeight: '700',
    marginBottom: 4,
  },
  pointsLabel: {
    fontSize: 14,
  },
  divider: {
    width: 1,
    height: 40,
  },
  multiplierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 12,
    justifyContent: 'center',
  },
  multiplierText: {
    fontSize: 14,
    fontWeight: '600',
  },
  quickActions: {
    marginTop: 24,
    marginBottom: 32,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionButton: {
    width: (width - 60) / 2,
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
  },
  actionIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionLabel: {
    fontSize: 14,
    fontWeight: '600',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
});
