import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../contexts/ThemeContext';
import { apiService } from '../../services/api';

interface Transaction {
  id: number;
  type: string;
  type_label: string;
  points: number;
  amount: number | null;
  balance_after: number;
  description: string;
  created_at: string;
  staff: { name: string } | null;
}

interface Membership {
  id: number;
  tenant: {
    business_name: string;
    business_slug: string;
  };
}

export default function TransactionsScreen() {
  const { colors } = useTheme();

  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [selectedMembership, setSelectedMembership] = useState<Membership | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    loadMemberships();
  }, []);

  useEffect(() => {
    if (selectedMembership) {
      loadTransactions();
      loadStats();
    }
  }, [selectedMembership]);

  const loadMemberships = async () => {
    try {
      const response = await apiService.getMemberships();
      if (response.success && response.data) {
        setMemberships(response.data.memberships);
        if (response.data.memberships.length > 0) {
          setSelectedMembership(response.data.memberships[0]);
        }
      }
    } catch (error) {
      console.error('Error loading memberships:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadTransactions = async () => {
    if (!selectedMembership) return;

    try {
      const response = await apiService.getTransactions(selectedMembership.tenant.business_slug, {
        per_page: 50,
      });
      if (response.success && response.data) {
        setTransactions(response.data.transactions);
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
  };

  const loadStats = async () => {
    if (!selectedMembership) return;

    try {
      const response = await apiService.getTransactionStats(selectedMembership.tenant.business_slug);
      if (response.success && response.data) {
        setStats(response.data);
      }
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([loadTransactions(), loadStats()]);
    setIsRefreshing(false);
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'earn':
        return { icon: 'arrow-up-circle', color: colors.success };
      case 'redeem':
        return { icon: 'arrow-down-circle', color: colors.danger };
      case 'bonus':
        return { icon: 'gift', color: colors.warning };
      case 'referral':
        return { icon: 'people', color: colors.info };
      case 'manual_add':
        return { icon: 'add-circle', color: colors.success };
      case 'manual_subtract':
        return { icon: 'remove-circle', color: colors.danger };
      case 'expire':
        return { icon: 'time', color: colors.textSecondary };
      default:
        return { icon: 'swap-horizontal', color: colors.textSecondary };
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      return `Today, ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }
  };

  const renderTransaction = ({ item }: { item: Transaction }) => {
    const iconData = getTransactionIcon(item.type);

    return (
      <View style={[styles.transactionCard, { backgroundColor: colors.card }]}>
        <View style={[styles.iconContainer, { backgroundColor: iconData.color + '20' }]}>
          <Ionicons name={iconData.icon as any} size={24} color={iconData.color} />
        </View>

        <View style={styles.transactionContent}>
          <Text style={[styles.transactionTitle, { color: colors.text }]}>{item.type_label}</Text>
          <Text style={[styles.transactionDescription, { color: colors.textSecondary }]} numberOfLines={1}>
            {item.description}
          </Text>
          <Text style={[styles.transactionDate, { color: colors.textSecondary }]}>
            {formatDate(item.created_at)}
          </Text>
        </View>

        <View style={styles.transactionRight}>
          <Text
            style={[
              styles.transactionPoints,
              { color: item.points > 0 ? colors.success : colors.danger },
            ]}
          >
            {item.points > 0 ? '+' : ''}
            {item.points}
          </Text>
          {item.amount && (
            <Text style={[styles.transactionAmount, { color: colors.textSecondary }]}>
              {item.amount} JOD
            </Text>
          )}
        </View>
      </View>
    );
  };

  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Transaction History</Text>
      </View>

      {/* Merchant Selector */}
      {memberships.length > 1 && (
        <View style={styles.merchantSelector}>
          <FlatList
            horizontal
            data={memberships}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={[
                  styles.merchantChip,
                  {
                    backgroundColor: selectedMembership?.id === item.id ? colors.primary : colors.surface,
                  },
                ]}
                onPress={() => setSelectedMembership(item)}
              >
                <Text
                  style={[
                    styles.merchantChipText,
                    {
                      color: selectedMembership?.id === item.id ? '#FFFFFF' : colors.text,
                    },
                  ]}
                >
                  {item.tenant.business_name}
                </Text>
              </TouchableOpacity>
            )}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.merchantList}
          />
        </View>
      )}

      {/* Stats Summary */}
      {stats && (
        <View style={[styles.statsCard, { backgroundColor: colors.card }]}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.success }]}>
              +{stats.summary.total_earned.toLocaleString()}
            </Text>
            <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Earned</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.danger }]}>
              -{stats.summary.total_redeemed.toLocaleString()}
            </Text>
            <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Redeemed</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.text }]}>
              {stats.summary.current_points.toLocaleString()}
            </Text>
            <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Balance</Text>
          </View>
        </View>
      )}

      {/* Transactions List */}
      <FlatList
        data={transactions}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderTransaction}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={handleRefresh} />}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="receipt-outline" size={80} color={colors.textSecondary} />
            <Text style={[styles.emptyText, { color: colors.text }]}>No transactions yet</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: '700',
  },
  merchantSelector: {
    paddingVertical: 16,
  },
  merchantList: {
    paddingHorizontal: 24,
    gap: 12,
  },
  merchantChip: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 12,
  },
  merchantChipText: {
    fontSize: 14,
    fontWeight: '600',
  },
  statsCard: {
    flexDirection: 'row',
    marginHorizontal: 24,
    marginBottom: 16,
    padding: 20,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
  },
  statDivider: {
    width: 1,
    marginHorizontal: 16,
  },
  list: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  transactionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  transactionContent: {
    flex: 1,
  },
  transactionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  transactionDescription: {
    fontSize: 14,
    marginBottom: 2,
  },
  transactionDate: {
    fontSize: 12,
  },
  transactionRight: {
    alignItems: 'flex-end',
  },
  transactionPoints: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  transactionAmount: {
    fontSize: 12,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
});
