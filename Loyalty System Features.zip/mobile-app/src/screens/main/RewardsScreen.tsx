import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  RefreshControl,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../contexts/ThemeContext';
import { apiService } from '../../services/api';

interface Reward {
  id: number;
  title: string;
  description: string;
  reward_type: string;
  points_required: number;
  discount_value: number | null;
  image_url: string | null;
  min_tier_required: string | null;
  quantity_available: number | null;
  can_redeem: boolean;
  redemption_status: {
    has_enough_points: boolean;
    tier_eligible: boolean;
    is_available: boolean;
    points_needed: number;
  };
}

interface Membership {
  id: number;
  tenant: {
    business_name: string;
    business_slug: string;
  };
}

export default function RewardsScreen() {
  const { colors } = useTheme();

  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [selectedMembership, setSelectedMembership] = useState<Membership | null>(null);
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isRedeeming, setIsRedeeming] = useState<number | null>(null);

  useEffect(() => {
    loadMemberships();
  }, []);

  useEffect(() => {
    if (selectedMembership) {
      loadRewards();
    }
  }, [selectedMembership]);

  const loadMemberships = async () => {
    try {
      const response = await apiService.getMemberships();
      if (response.success && response.data) {
        setMemberships(response.data.memberships);
        if (response.data.memberships.length > 0) {
          setSelectedMembership(response.data.memberships[0]);
        }
      }
    } catch (error) {
      console.error('Error loading memberships:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadRewards = async () => {
    if (!selectedMembership) return;

    try {
      const response = await apiService.getRewards(selectedMembership.tenant.business_slug);
      if (response.success && response.data) {
        setRewards(response.data.rewards);
      }
    } catch (error) {
      console.error('Error loading rewards:', error);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadRewards();
    setIsRefreshing(false);
  };

  const handleRedeemReward = async (reward: Reward) => {
    if (!selectedMembership) return;

    if (!reward.can_redeem) {
      if (!reward.redemption_status.has_enough_points) {
        Alert.alert(
          'Insufficient Points',
          `You need ${reward.redemption_status.points_needed} more points to redeem this reward.`
        );
      } else if (!reward.redemption_status.tier_eligible) {
        Alert.alert('Tier Required', `This reward requires ${reward.min_tier_required} tier or higher.`);
      } else {
        Alert.alert('Unavailable', 'This reward is currently unavailable.');
      }
      return;
    }

    Alert.alert(
      'Redeem Reward',
      `Redeem "${reward.title}" for ${reward.points_required} points?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Redeem',
          onPress: async () => {
            setIsRedeeming(reward.id);
            try {
              const response = await apiService.redeemReward(
                selectedMembership.tenant.business_slug,
                reward.id
              );

              if (response.success && response.data) {
                Alert.alert(
                  'Success!',
                  `Redemption code: ${response.data.redemption.redemption_code}\n\nShow this code to the staff.`,
                  [{ text: 'OK', onPress: () => loadRewards() }]
                );
              }
            } catch (error: any) {
              Alert.alert('Error', error.message || 'Failed to redeem reward');
            } finally {
              setIsRedeeming(null);
            }
          },
        },
      ]
    );
  };

  const renderRewardType = (type: string, value: number | null) => {
    switch (type) {
      case 'free_product':
        return 'Free Item';
      case 'percentage_discount':
        return `${value}% Off`;
      case 'fixed_discount':
        return `${value} JOD Off`;
      case 'experience':
        return 'Experience';
      default:
        return 'Reward';
    }
  };

  const renderReward = ({ item }: { item: Reward }) => (
    <TouchableOpacity
      style={[styles.rewardCard, { backgroundColor: colors.card }]}
      onPress={() => handleRedeemReward(item)}
      activeOpacity={0.8}
      disabled={isRedeeming === item.id}
    >
      {/* Image or Icon */}
      <View style={[styles.rewardImage, { backgroundColor: colors.surface }]}>
        {item.image_url ? (
          <Image source={{ uri: item.image_url }} style={styles.image} resizeMode="cover" />
        ) : (
          <Ionicons name="gift" size={40} color={colors.primary} />
        )}
      </View>

      {/* Content */}
      <View style={styles.rewardContent}>
        <View style={styles.rewardHeader}>
          <Text style={[styles.rewardTitle, { color: colors.text }]} numberOfLines={2}>
            {item.title}
          </Text>
          <View style={[styles.typeBadge, { backgroundColor: colors.surface }]}>
            <Text style={[styles.typeText, { color: colors.primary }]}>
              {renderRewardType(item.reward_type, item.discount_value)}
            </Text>
          </View>
        </View>

        <Text style={[styles.rewardDescription, { color: colors.textSecondary }]} numberOfLines={2}>
          {item.description}
        </Text>

        {/* Footer */}
        <View style={styles.rewardFooter}>
          <View style={styles.pointsBadge}>
            <Ionicons name="star" size={16} color={colors.warning} />
            <Text style={[styles.pointsText, { color: colors.text }]}>
              {item.points_required} points
            </Text>
          </View>

          {isRedeeming === item.id ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <TouchableOpacity
              style={[
                styles.redeemButton,
                {
                  backgroundColor: item.can_redeem ? colors.primary : colors.disabled,
                },
              ]}
              onPress={() => handleRedeemReward(item)}
              disabled={!item.can_redeem}
            >
              <Text style={styles.redeemButtonText}>
                {item.can_redeem ? 'Redeem' : 'Locked'}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Status indicator */}
        {!item.can_redeem && (
          <View style={styles.statusIndicator}>
            {!item.redemption_status.has_enough_points && (
              <Text style={[styles.statusText, { color: colors.danger }]}>
                Need {item.redemption_status.points_needed} more points
              </Text>
            )}
            {!item.redemption_status.tier_eligible && (
              <Text style={[styles.statusText, { color: colors.warning }]}>
                Requires {item.min_tier_required} tier
              </Text>
            )}
          </View>
        )}
      </View>
    </TouchableOpacity>
  );

  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Rewards</Text>
      </View>

      {/* Merchant Selector */}
      {memberships.length > 1 && (
        <View style={styles.merchantSelector}>
          <FlatList
            horizontal
            data={memberships}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={[
                  styles.merchantChip,
                  {
                    backgroundColor: selectedMembership?.id === item.id ? colors.primary : colors.surface,
                  },
                ]}
                onPress={() => setSelectedMembership(item)}
              >
                <Text
                  style={[
                    styles.merchantChipText,
                    {
                      color: selectedMembership?.id === item.id ? '#FFFFFF' : colors.text,
                    },
                  ]}
                >
                  {item.tenant.business_name}
                </Text>
              </TouchableOpacity>
            )}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.merchantList}
          />
        </View>
      )}

      {/* Rewards List */}
      <FlatList
        data={rewards}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderReward}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={handleRefresh} />}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="gift-outline" size={80} color={colors.textSecondary} />
            <Text style={[styles.emptyText, { color: colors.text }]}>No rewards available</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: '700',
  },
  merchantSelector: {
    paddingVertical: 16,
  },
  merchantList: {
    paddingHorizontal: 24,
    gap: 12,
  },
  merchantChip: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 12,
  },
  merchantChipText: {
    fontSize: 14,
    fontWeight: '600',
  },
  list: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  rewardCard: {
    flexDirection: 'row',
    borderRadius: 16,
    marginBottom: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  rewardImage: {
    width: 100,
    height: 100,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
  },
  rewardContent: {
    flex: 1,
  },
  rewardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  rewardTitle: {
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    marginRight: 8,
  },
  typeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  typeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  rewardDescription: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 12,
  },
  rewardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  pointsText: {
    fontSize: 14,
    fontWeight: '600',
  },
  redeemButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
  },
  redeemButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  statusIndicator: {
    marginTop: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
});
