import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import * as SecureStore from 'expo-secure-store';
import { apiService } from '../services/api';

interface Customer {
  id: number;
  full_name: string;
  phone_number: string;
  email: string | null;
  language: string;
  phone_verified: boolean;
  email_verified: boolean;
}

interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  customer: Customer | null;
  token: string | null;
  login: (token: string, customer: Customer) => Promise<void>;
  logout: () => Promise<void>;
  updateCustomer: (customer: Customer) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const TOKEN_KEY = 'auth_token';
const CUSTOMER_KEY = 'customer_data';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    loadAuthState();
  }, []);

  const loadAuthState = async () => {
    try {
      const savedToken = await SecureStore.getItemAsync(TOKEN_KEY);
      const savedCustomer = await SecureStore.getItemAsync(CUSTOMER_KEY);

      if (savedToken && savedCustomer) {
        const customerData = JSON.parse(savedCustomer);
        setToken(savedToken);
        setCustomer(customerData);
        setIsAuthenticated(true);

        // Set token in API service
        apiService.setToken(savedToken);

        // Verify token is still valid by fetching profile
        try {
          const response = await apiService.getProfile();
          if (response.success) {
            setCustomer(response.data.customer);
            await SecureStore.setItemAsync(CUSTOMER_KEY, JSON.stringify(response.data.customer));
          }
        } catch (error) {
          // Token invalid, logout
          await logout();
        }
      }
    } catch (error) {
      console.error('Error loading auth state:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (authToken: string, customerData: Customer) => {
    try {
      // Save to secure storage
      await SecureStore.setItemAsync(TOKEN_KEY, authToken);
      await SecureStore.setItemAsync(CUSTOMER_KEY, JSON.stringify(customerData));

      // Update state
      setToken(authToken);
      setCustomer(customerData);
      setIsAuthenticated(true);

      // Set token in API service
      apiService.setToken(authToken);
    } catch (error) {
      console.error('Error saving auth data:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      // Call logout API
      if (token) {
        await apiService.logout();
      }
    } catch (error) {
      console.error('Error calling logout API:', error);
    } finally {
      // Clear secure storage
      await SecureStore.deleteItemAsync(TOKEN_KEY);
      await SecureStore.deleteItemAsync(CUSTOMER_KEY);

      // Clear state
      setToken(null);
      setCustomer(null);
      setIsAuthenticated(false);

      // Clear token from API service
      apiService.setToken(null);
    }
  };

  const updateCustomer = (customerData: Customer) => {
    setCustomer(customerData);
    SecureStore.setItemAsync(CUSTOMER_KEY, JSON.stringify(customerData));
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isLoading,
        customer,
        token,
        login,
        logout,
        updateCustomer,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
