import axios, { AxiosInstance, AxiosError } from 'axios';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig?.extra?.apiUrl || 'http://localhost:8000/api';

interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  errors?: Record<string, string[]>;
}

class ApiService {
  private client: AxiosInstance;
  private token: string | null = null;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    });

    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        if (this.token) {
          config.headers.Authorization = `Bearer ${this.token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => response.data,
      (error: AxiosError<ApiResponse>) => {
        if (error.response) {
          throw error.response.data;
        }
        throw { success: false, message: 'Network error. Please check your connection.' };
      }
    );
  }

  setToken(token: string | null) {
    this.token = token;
  }

  // Authentication
  async sendOtp(phoneNumber: string): Promise<ApiResponse> {
    return this.client.post('/auth/send-otp', { phone_number: phoneNumber });
  }

  async verifyOtp(phoneNumber: string, otp: string, fullName?: string, language?: string): Promise<ApiResponse> {
    return this.client.post('/auth/verify-otp', {
      phone_number: phoneNumber,
      otp,
      full_name: fullName,
      language,
    });
  }

  async login(email: string, password: string): Promise<ApiResponse> {
    return this.client.post('/auth/login', { email, password });
  }

  async logout(): Promise<ApiResponse> {
    return this.client.post('/auth/logout');
  }

  async getProfile(): Promise<ApiResponse> {
    return this.client.get('/auth/me');
  }

  async updateProfile(data: {
    full_name?: string;
    email?: string;
    date_of_birth?: string;
    language?: string;
  }): Promise<ApiResponse> {
    return this.client.put('/auth/profile', data);
  }

  // Memberships
  async getMemberships(): Promise<ApiResponse> {
    return this.client.get('/memberships');
  }

  async getMembership(tenantSlug: string): Promise<ApiResponse> {
    return this.client.get(`/memberships/${tenantSlug}`);
  }

  async getMembershipPoints(tenantSlug: string): Promise<ApiResponse> {
    return this.client.get(`/memberships/${tenantSlug}/points`);
  }

  async joinMerchant(tenantSlug: string): Promise<ApiResponse> {
    return this.client.post(`/memberships/${tenantSlug}/join`);
  }

  // Rewards
  async getRewards(tenantSlug: string): Promise<ApiResponse> {
    return this.client.get(`/tenants/${tenantSlug}/rewards`);
  }

  async getReward(tenantSlug: string, rewardId: number): Promise<ApiResponse> {
    return this.client.get(`/tenants/${tenantSlug}/rewards/${rewardId}`);
  }

  async redeemReward(tenantSlug: string, rewardId: number): Promise<ApiResponse> {
    return this.client.post(`/tenants/${tenantSlug}/rewards/${rewardId}/redeem`);
  }

  async getRedemptions(tenantSlug: string): Promise<ApiResponse> {
    return this.client.get(`/tenants/${tenantSlug}/redemptions`);
  }

  // Transactions
  async getTransactions(
    tenantSlug: string,
    params?: { per_page?: number; type?: string; from_date?: string; to_date?: string }
  ): Promise<ApiResponse> {
    return this.client.get(`/tenants/${tenantSlug}/transactions`, { params });
  }

  async getTransactionStats(tenantSlug: string): Promise<ApiResponse> {
    return this.client.get(`/tenants/${tenantSlug}/transactions/stats`);
  }

  async getAllTransactions(params?: { per_page?: number }): Promise<ApiResponse> {
    return this.client.get('/transactions', { params });
  }

  // QR Codes
  async getQRCode(tenantSlug: string): Promise<ApiResponse> {
    return this.client.get(`/tenants/${tenantSlug}/qr-code`);
  }

  async getAllQRCodes(): Promise<ApiResponse> {
    return this.client.get('/qr-codes');
  }

  // Notifications
  async getNotifications(params?: { per_page?: number; unread_only?: boolean }): Promise<ApiResponse> {
    return this.client.get('/notifications', { params });
  }

  async getUnreadCount(): Promise<ApiResponse> {
    return this.client.get('/notifications/unread-count');
  }

  async markNotificationAsRead(id: number): Promise<ApiResponse> {
    return this.client.put(`/notifications/${id}/read`);
  }

  async markAllNotificationsAsRead(): Promise<ApiResponse> {
    return this.client.put('/notifications/read-all');
  }

  async deleteNotification(id: number): Promise<ApiResponse> {
    return this.client.delete(`/notifications/${id}`);
  }

  async updateDeviceToken(deviceToken: string, deviceType: 'ios' | 'android'): Promise<ApiResponse> {
    return this.client.post('/notifications/device-token', {
      device_token: deviceToken,
      device_type: deviceType,
    });
  }
}

export const apiService = new ApiService();
