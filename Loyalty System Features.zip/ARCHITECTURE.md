# 🏗️ System Architecture

## Overview

This document visualizes the complete architecture of the Loyalty System.

---

## 🗂️ Multi-Tenant Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     LOYALTY SYSTEM SaaS                      │
│                    (Single Application)                      │
└─────────────────────────────────────────────────────────────┘
                              │
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│  Tenant #1    │     │  Tenant #2    │     │  Tenant #3    │
│  Café Aroma   │     │ Fresh Fitness │     │ Bella Salon   │
├───────────────┤     ├───────────────┤     ├───────────────┤
│ cafe-aroma    │     │ fresh-fitness │     │ bella-salon   │
│ .domain.com   │     │ .domain.com   │     │ .domain.com   │
└───────────────┘     └───────────────┘     └───────────────┘
        │                     │                     │
        │                     │                     │
   [Customers]           [Customers]           [Customers]
   [Rewards]             [Rewards]             [Rewards]
   [Staff]               [Staff]               [Staff]
```

**Key Points:**
- ✅ Each tenant has unique subdomain
- ✅ Complete data isolation via `tenant_id`
- ✅ Shared codebase, separate data
- ✅ Scalable to 1000+ tenants

---

## 🎨 Three-Layer Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Mobile App │  │   Merchant   │  │ Super Admin  │      │
│  │ (React Native│  │  Dashboard   │  │   Dashboard  │      │
│  │   + Expo)    │  │ (Filament 3) │  │ (Filament 3) │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                              │
└───────────────────────────┬──────────────────────────────────┘
                            │
                            │ REST API / Web Routes
                            │
┌───────────────────────────▼──────────────────────────────────┐
│                     BUSINESS LOGIC LAYER                      │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │   Points     │  │   Rewards    │  │     QR       │       │
│  │   Service    │  │   Service    │  │   Service    │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ Notification │  │     Tier     │  │ Subscription │       │
│  │   Service    │  │   Service    │  │   Service    │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
│                                                               │
└───────────────────────────┬──────────────────────────────────┘
                            │
                            │ Eloquent ORM
                            │
┌───────────────────────────▼──────────────────────────────────┐
│                       DATA ACCESS LAYER                       │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │
│  │ Tenants  │  │Customers │  │ Rewards  │  │  Tiers   │     │
│  │  Model   │  │  Model   │  │  Model   │  │  Model   │     │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘     │
│                                                               │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │
│  │Transaction│ │Redemption│  │  Staff   │  │Notification│   │
│  │  Model   │  │  Model   │  │  Model   │  │  Model   │     │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘     │
│                                                               │
└───────────────────────────┬──────────────────────────────────┘
                            │
                            │ SQL Queries
                            │
┌───────────────────────────▼──────────────────────────────────┐
│                       DATABASE LAYER                          │
├──────────────────────────────────────────────────────────────┤
│                      MySQL 8.0+                               │
│                   (10 Tables + Indexes)                       │
└──────────────────────────────────────────────────────────────┘
```

---

## 📱 User Flows

### Customer Journey

```
┌─────────────┐
│   Customer  │
│  Downloads  │
│   App       │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Register   │──────► Phone + OTP
│  Account    │        Verification
└──────┬──────┘
       │
       ▼
┌─────────────┐
│    Join     │──────► Scan merchant QR
│  Merchant   │        or search
└──────┬──────┘
       │
       ▼
┌─────────────┐
│    Make     │──────► Staff scans
│  Purchase   │        customer QR
└──────┬──────┘
       │
       ▼
┌─────────────┐
│    Earn     │──────► Points added
│   Points    │        (with multiplier)
└──────┬──────┘
       │
       ▼
┌─────────────┐
│    Tier     │──────► Auto-upgrade
│   Upgrade?  │        if eligible
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Browse    │──────► Filter by
│   Rewards   │        category/points
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Redeem    │──────► Deduct points
│   Reward    │        Create redemption
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Staff     │──────► Approve/Reject
│  Approves   │        or Mark as Used
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Customer   │──────► Notification
│   Uses      │        Sent
│  Reward     │
└─────────────┘
```

---

### Merchant Journey

```
┌─────────────┐
│  Merchant   │
│  Signs Up   │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Choose    │──────► Free Trial / Paid
│    Plan     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Configure  │──────► 1 JOD = X points
│   Points    │        Expiry, bonuses
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Customize  │──────► Thresholds
│    Tiers    │        Multipliers
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Create    │──────► Free products
│   Rewards   │        Discounts
└──────┬──────┘
       │
       ▼
┌─────────────┐
│     Add     │──────► Assign roles
│    Staff    │        Set permissions
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Launch!   │──────► Share QR code
│             │        with customers
└─────────────┘
```

---

## 🔄 Points Flow

### Earning Points

```
Customer Purchase (50 JOD)
         │
         ▼
┌────────────────────┐
│  Points Settings   │
│  1 JOD = 10 points │──────► Base Points = 500
└────────────────────┘
         │
         ▼
┌────────────────────┐
│  Customer Tier     │
│  Silver (1.5x)     │──────► Multiplied = 750
└────────────────────┘
         │
         ▼
┌────────────────────┐
│  Create Transaction│
│  Type: earn        │
│  Points: +750      │
└────────────────────┘
         │
         ▼
┌────────────────────┐
│ Update Membership  │
│ current_points += 750
│ total_earned += 750
│ total_visits += 1  │
└────────────────────┘
         │
         ▼
┌────────────────────┐
│  Check Tier        │
│  Upgrade?          │──────► If eligible,
└────────────────────┘        upgrade tier
         │
         ▼
┌────────────────────┐
│  Send Notification │
│  "You earned 750   │
│   points!"         │
└────────────────────┘
```

### Redeeming Points

```
Customer Selects Reward (Free Coffee - 100 points)
         │
         ▼
┌────────────────────┐
│  Check Eligibility │
│  - Enough points?  │
│  - Tier qualified? │
│  - In stock?       │
└────────┬───────────┘
         │
         ▼
┌────────────────────┐
│ Create Redemption  │
│ Status: pending    │
│ Points: 100        │
└────────────────────┘
         │
         ▼
┌────────────────────┐
│ Create Transaction │
│ Type: redeem       │
│ Points: -100       │
└────────────────────┘
         │
         ▼
┌────────────────────┐
│ Update Membership  │
│ current_points -= 100
│ total_redeemed += 100
└────────────────────┘
         │
         ▼
┌────────────────────┐
│  Staff Approves    │──────► Status: approved
│                    │
└────────────────────┘
         │
         ▼
┌────────────────────┐
│  Customer Uses     │──────► Status: used
│  Reward            │
└────────────────────┘
```

---

## 🔐 Authentication Flow

### Mobile App (Customer)

```
┌─────────────┐
│   Enter     │
│   Phone     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Send OTP   │──────► SMS/WhatsApp
│             │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Verify OTP │
│             │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Generate   │──────► Laravel Sanctum
│  JWT Token  │        Token
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Store     │──────► AsyncStorage
│   Token     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Access    │
│     App     │
└─────────────┘
```

### Staff/Merchant (Dashboard)

```
┌─────────────┐
│   Enter     │
│Email + Pass │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Laravel    │
│  Fortify    │
│  Auth       │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Session    │──────► Cookie-based
│  Created    │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Dashboard  │
│   Access    │
└─────────────┘
```

---

## 🎯 Data Isolation Strategy

### How Multi-Tenancy Works

```
Request: https://cafe-aroma.loyaltysystem.com/api/customers
                      │
                      ▼
            ┌─────────────────┐
            │  Subdomain      │
            │  Middleware     │──────► Extract: "cafe-aroma"
            └────────┬────────┘
                     │
                     ▼
            ┌─────────────────┐
            │  Find Tenant    │──────► SELECT * FROM tenants
            │  by slug        │        WHERE business_slug = 'cafe-aroma'
            └────────┬────────┘
                     │
                     ▼
            ┌─────────────────┐
            │  Set Tenant     │──────► app('tenant')->set($tenant)
            │  Context        │
            └────────┬────────┘
                     │
                     ▼
            ┌─────────────────┐
            │  All Queries    │──────► SELECT * FROM customers
            │  Auto-Scoped    │        WHERE tenant_id = 1
            └────────┬────────┘
                     │
                     ▼
            ┌─────────────────┐
            │  Return Only    │
            │  Tenant Data    │
            └─────────────────┘
```

**Safety Measures:**
- ✅ Middleware enforces tenant context
- ✅ Global scope on all models
- ✅ Foreign key constraints
- ✅ No cross-tenant data access

---

## 🔔 Notification Architecture

```
Trigger Event (e.g., Points Earned)
         │
         ▼
┌────────────────────┐
│  Notification      │
│  Service           │
└────────┬───────────┘
         │
    ┌────┴────┐
    │         │         │
    ▼         ▼         ▼
┌──────┐  ┌──────┐  ┌──────┐
│ Push │  │Email │  │ SMS  │
│ (FCM)│  │(Send │  │(Twilio)│
└──┬───┘  │Grid) │  └──┬───┘
   │      └──┬───┘     │
   │         │         │
   └────┬────┴────┬────┘
        │         │
        ▼         ▼
   ┌─────────────────┐
   │  Customer       │
   │  Receives       │
   │  Notification   │
   └─────────────────┘
```

**Channels:**
- **Push:** Firebase Cloud Messaging (real-time)
- **Email:** SendGrid (transactional)
- **SMS:** Twilio (optional, paid)
- **WhatsApp:** Meta Business API (Phase 2)

---

## 📊 Tech Stack Visualization

```
┌─────────────────────────────────────────────────────────────┐
│                        FRONTEND                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Mobile App:          Dashboards:                            │
│  • React Native       • Filament 3                           │
│  • Expo               • Tailwind CSS                         │
│  • React Navigation   • Alpine.js                            │
│                                                              │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                         BACKEND                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Framework:           Authentication:                        │
│  • Laravel 11         • Laravel Sanctum (API)                │
│  • PHP 8.2+           • Laravel Fortify (Web)                │
│                                                              │
│  Multi-Tenancy:       Queue/Cache:                           │
│  • stancl/tenancy     • Redis                                │
│                                                              │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                        DATABASE                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Primary:             Search (Optional):                     │
│  • MySQL 8.0+         • Elasticsearch                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                   THIRD-PARTY SERVICES                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  • Stripe (Payments)                                         │
│  • Firebase (Push Notifications)                             │
│  • SendGrid (Email)                                          │
│  • Twilio (SMS - optional)                                   │
│  • CloudFlare (CDN)                                          │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Deployment Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      CLOUDFLARE CDN                          │
│               (SSL, DDoS Protection, Cache)                  │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                     LOAD BALANCER                            │
│                  (NGINX / AWS ALB)                           │
└─────────────┬───────────────────────┬───────────────────────┘
              │                       │
      ┌───────▼───────┐       ┌───────▼───────┐
      │   App Server  │       │   App Server  │
      │   Instance 1  │       │   Instance 2  │
      │   (Laravel)   │       │   (Laravel)   │
      └───────┬───────┘       └───────┬───────┘
              │                       │
              └───────┬───────────────┘
                      │
              ┌───────▼───────┐
              │   MySQL DB    │
              │   (Primary)   │
              └───────┬───────┘
                      │
              ┌───────▼───────┐
              │   MySQL DB    │
              │  (Read Replica)│
              └───────────────┘

              ┌───────────────┐
              │  Redis Cache  │
              │   & Queues    │
              └───────────────┘

              ┌───────────────┐
              │  File Storage │
              │   (S3/Spaces) │
              └───────────────┘
```

---

## 📈 Scalability Plan

### Phase 1: 1-100 Merchants
```
Single Server
├── Laravel App
├── MySQL Database
└── Redis Cache
```

### Phase 2: 100-500 Merchants
```
Load Balancer
├── App Server 1
├── App Server 2
├── MySQL Primary
├── MySQL Read Replica
└── Redis Cluster
```

### Phase 3: 500-1000+ Merchants
```
Auto-Scaling Group
├── 5+ App Servers
├── MySQL Cluster (Sharding)
├── Redis Cluster
├── Elasticsearch
└── CDN for Assets
```

---

## 🔒 Security Layers

```
┌─────────────────────────────────────────────────────────────┐
│  Layer 1: Network Security                                   │
│  • CloudFlare WAF                                            │
│  • DDoS Protection                                           │
│  • Rate Limiting                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  Layer 2: Application Security                               │
│  • HTTPS Enforced (SSL)                                      │
│  • CSRF Protection                                           │
│  • XSS Protection                                            │
│  • SQL Injection Prevention                                  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  Layer 3: Authentication & Authorization                     │
│  • JWT Tokens (API)                                          │
│  • Session-based (Web)                                       │
│  • OTP Verification                                          │
│  • Role-Based Access Control (RBAC)                          │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  Layer 4: Data Security                                      │
│  • Tenant Isolation                                          │
│  • Encrypted Passwords (bcrypt)                              │
│  • Encrypted API Keys                                        │
│  • Database Backups (Daily)                                  │
└─────────────────────────────────────────────────────────────┘
```

---

**Last Updated:** November 2024
**Version:** 1.0
