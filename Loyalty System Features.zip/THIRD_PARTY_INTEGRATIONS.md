# Third-Party Integrations Guide

**Phase 1, Step 5: Third-Party Integrations**

**Date:** November 29, 2025

---

## Overview

This document provides complete setup instructions for all third-party services integrated into the Loyalty System.

---

## Table of Contents

1. [Stripe - Subscription Payments](#stripe---subscription-payments)
2. [Firebase Cloud Messaging - Push Notifications](#firebase-cloud-messaging---push-notifications)
3. [Twilio - SMS & OTP](#twilio---sms--otp)
4. [SendGrid - Email Service](#sendgrid---email-service)
5. [Environment Variables](#environment-variables)
6. [Testing](#testing)

---

## Stripe - Subscription Payments

### Purpose
Manage merchant subscription payments, plan limits, and billing.

### Setup Instructions

#### 1. Create Stripe Account
- Go to [https://stripe.com](https://stripe.com)
- Sign up for a Stripe account
- Complete business verification

#### 2. Get API Keys
- Navigate to **Developers → API keys**
- Copy **Publishable key** and **Secret key**
- Use **test mode** for development

#### 3. Create Products & Prices
Create 3 products in Stripe Dashboard:

**Starter Plan ($29/month)**
- Product Name: "Starter Plan"
- Price: $29 USD/month
- Recurring billing: Monthly
- Copy Price ID (e.g., `price_1ABC...`)

**Professional Plan ($99/month)**
- Product Name: "Professional Plan"
- Price: $99 USD/month
- Recurring billing: Monthly
- Copy Price ID

**Enterprise Plan ($299/month)**
- Product Name: "Enterprise Plan"
- Price: $299 USD/month
- Recurring billing: Monthly
- Copy Price ID

#### 4. Set Up Webhooks
- Navigate to **Developers → Webhooks**
- Click **Add endpoint**
- Endpoint URL: `https://yourdomain.com/stripe/webhook`
- Select events:
  - `customer.subscription.created`
  - `customer.subscription.updated`
  - `customer.subscription.deleted`
  - `invoice.payment_succeeded`
  - `invoice.payment_failed`
  - `customer.subscription.trial_will_end`
- Copy **Webhook signing secret**

#### 5. Configure Environment Variables

```env
# Stripe Configuration
STRIPE_KEY=pk_test_51ABC...
STRIPE_SECRET=sk_test_51ABC...
STRIPE_WEBHOOK_SECRET=whsec_...

# Stripe Price IDs
STRIPE_STARTER_PRICE_ID=price_1ABC...
STRIPE_PROFESSIONAL_PRICE_ID=price_1DEF...
STRIPE_ENTERPRISE_PRICE_ID=price_1GHI...
```

### Usage Examples

#### Create Subscription for Tenant

```php
use App\Services\StripeService;
use App\Models\Tenant;

$stripeService = new StripeService();
$tenant = Tenant::find(1);

// Create subscription
$subscription = $stripeService->createSubscription(
    $tenant,
    'professional',  // Plan name
    'pm_card_visa'   // Payment method ID from frontend
);
```

#### Change Plan

```php
$subscription = $stripeService->changePlan($tenant, 'enterprise');
```

#### Cancel Subscription

```php
// Cancel at period end
$subscription = $stripeService->cancelSubscription($tenant, false);

// Cancel immediately
$subscription = $stripeService->cancelSubscription($tenant, true);
```

#### Get Upcoming Invoice

```php
$invoice = $stripeService->getUpcomingInvoice($tenant);
```

### Plan Limits

Plans automatically set limits on tenant resources:

| Plan | Customers | Staff | Rewards | Price |
|------|-----------|-------|---------|-------|
| Free Trial | 50 | 1 | 5 | $0 (14 days) |
| Starter | 500 | 3 | 20 | $29/mo |
| Professional | 2,000 | 10 | 50 | $99/mo |
| Enterprise | Unlimited | Unlimited | Unlimited | $299/mo |

---

## Firebase Cloud Messaging - Push Notifications

### Purpose
Send real-time push notifications to mobile app users.

### Setup Instructions

#### 1. Create Firebase Project
- Go to [https://console.firebase.google.com](https://console.firebase.google.com)
- Click **Add project**
- Project name: "Loyalty System"
- Enable Google Analytics (optional)

#### 2. Add Android App
- Click **Add app** → **Android**
- Package name: `com.loyalty.app` (matches mobile app)
- Download `google-services.json`
- Place in mobile app: `mobile-app/android/app/`

#### 3. Add iOS App
- Click **Add app** → **iOS**
- Bundle ID: `com.loyalty.app`
- Download `GoogleService-Info.plist`
- Place in mobile app: `mobile-app/ios/`

#### 4. Get Server Key
- Navigate to **Project Settings → Cloud Messaging**
- Copy **Server key** (Legacy)
- Copy **Sender ID**

#### 5. Get Service Account Credentials
- Navigate to **Project Settings → Service Accounts**
- Click **Generate new private key**
- Download JSON file
- Place in Laravel: `storage/app/firebase-credentials.json`

#### 6. Configure Environment Variables

```env
# Firebase Configuration
FIREBASE_PROJECT_ID=loyalty-system-xxxxx
FIREBASE_SERVER_KEY=AAAA...
FIREBASE_DATABASE_URL=https://loyalty-system-xxxxx.firebaseio.com
FIREBASE_CREDENTIALS=storage/app/firebase-credentials.json
```

### Usage Examples

#### Send Points Earned Notification

```php
use App\Services\FirebaseService;

$firebaseService = new FirebaseService();

$firebaseService->sendPointsEarnedNotification(
    $deviceToken,
    50,  // Points earned
    'Café Aroma',
    'en'  // Language
);
```

#### Send Tier Upgrade Notification

```php
$firebaseService->sendTierUpgradeNotification(
    $deviceToken,
    'Gold',  // New tier
    'Café Aroma',
    'ar'  // Arabic
);
```

#### Send Custom Notification

```php
$firebaseService->sendToDevice(
    $deviceToken,
    [
        'title' => 'Special Offer!',
        'body' => '50% off all items today!',
    ],
    [
        'type' => 'promotion',
        'offer_id' => 123,
    ]
);
```

### Notification Types

The system supports these notification types:
- `points_earned` - Points added
- `tier_upgrade` - Tier promotion
- `reward_redeemed` - Reward claimed
- `reward_available` - New reward added
- `points_expiring` - Points about to expire
- `welcome_bonus` - Join bonus
- `birthday_bonus` - Birthday reward
- `referral_bonus` - Referral reward

---

## Twilio - SMS & OTP

### Purpose
Send SMS messages and OTP verification codes.

### Setup Instructions

#### 1. Create Twilio Account
- Go to [https://www.twilio.com](https://www.twilio.com)
- Sign up for an account
- Verify your email and phone number

#### 2. Get Credentials
- Navigate to **Console Dashboard**
- Copy **Account SID**
- Copy **Auth Token**

#### 3. Get Phone Number
- Navigate to **Phone Numbers → Manage → Buy a number**
- Choose country: **Jordan (+962)** or **United States (+1)**
- Select a number with SMS capability
- Purchase number
- Copy the phone number (e.g., `+14155551234`)

#### 4. Set Up Verify Service (For OTP)
- Navigate to **Verify → Services**
- Click **Create new service**
- Friendly name: "Loyalty System OTP"
- Copy **Service SID** (starts with `VA...`)

#### 5. Configure Environment Variables

```env
# Twilio Configuration
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_FROM_NUMBER=+14155551234
TWILIO_VERIFY_SID=VAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### Usage Examples

#### Send OTP

```php
use App\Services\TwilioService;

$twilioService = new TwilioService();

// Send OTP via SMS
$twilioService->sendOtp('+962791234567', 'sms');

// Or via WhatsApp
$twilioService->sendOtp('+962791234567', 'whatsapp');
```

#### Verify OTP

```php
$isValid = $twilioService->verifyOtp('+962791234567', '123456');

if ($isValid) {
    // OTP is correct
} else {
    // Invalid OTP
}
```

#### Send Custom SMS

```php
$twilioService->sendSms(
    '+962791234567',
    'Your reward redemption code is: ABC123'
);
```

#### Send Redemption Confirmation

```php
$twilioService->sendRedemptionConfirmation(
    '+962791234567',
    'Free Coffee',
    'ABC12XYZ'
);
```

### Twilio Verify Benefits

Using Twilio Verify Service provides:
- ✅ Automatic OTP generation
- ✅ Built-in rate limiting
- ✅ Fraud detection
- ✅ Multiple delivery channels (SMS, Voice, WhatsApp)
- ✅ Automatic retry logic
- ✅ No need to store OTPs in database

---

## SendGrid - Email Service

### Purpose
Send transactional and marketing emails to customers.

### Setup Instructions

#### 1. Create SendGrid Account
- Go to [https://sendgrid.com](https://sendgrid.com)
- Sign up for an account
- Complete sender verification

#### 2. Verify Sender Identity
- Navigate to **Settings → Sender Authentication**
- Click **Verify a Single Sender**
- Enter email: `noreply@yourdomain.com`
- Verify email address

#### 3. Create API Key
- Navigate to **Settings → API Keys**
- Click **Create API Key**
- Name: "Loyalty System"
- Permissions: **Full Access**
- Copy API key (starts with `SG.`)

#### 4. Create Email Templates (Optional)
- Navigate to **Email API → Dynamic Templates**
- Create templates for:
  - Welcome email
  - Tier upgrade
  - Reward redeemed
  - Points expiring
  - Monthly summary
- Copy Template IDs

#### 5. Configure Environment Variables

```env
# SendGrid Configuration
SENDGRID_API_KEY=SG.xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SENDGRID_FROM_EMAIL=noreply@yourdomain.com
SENDGRID_FROM_NAME=Loyalty System

# SendGrid Templates (Optional)
SENDGRID_TEMPLATE_WELCOME=d-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SENDGRID_TEMPLATE_TIER_UPGRADE=d-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SENDGRID_TEMPLATE_REWARD_REDEEMED=d-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SENDGRID_TEMPLATE_POINTS_EXPIRING=d-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SENDGRID_TEMPLATE_MONTHLY_SUMMARY=d-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### Usage Examples

#### Send Welcome Email

```php
use App\Services\SendGridService;

$sendGridService = new SendGridService();

$sendGridService->sendWelcomeEmail(
    'customer@example.com',
    'Ahmad Khalil',
    'Café Aroma',
    100  // Bonus points
);
```

#### Send Tier Upgrade Email

```php
$sendGridService->sendTierUpgradeEmail(
    'customer@example.com',
    'Ahmad Khalil',
    'Gold Member',
    'Café Aroma'
);
```

#### Send Redemption Confirmation

```php
$sendGridService->sendRedemptionConfirmation(
    'customer@example.com',
    'Ahmad Khalil',
    'Free Coffee',
    'ABC12XYZ'
);
```

#### Send Monthly Summary

```php
$sendGridService->sendMonthlySummary(
    'customer@example.com',
    'Ahmad Khalil',
    450,   // Points earned
    200,   // Points redeemed
    1250,  // Current balance
    'Café Aroma'
);
```

#### Send Custom Email

```php
$sendGridService->sendEmail(
    'customer@example.com',
    'Special Promotion',
    '<h1>Flash Sale!</h1><p>50% off today only!</p>',
    'Flash Sale! 50% off today only!'
);
```

---

## Environment Variables

### Complete `.env` Configuration

```env
# Application
APP_NAME="Loyalty System"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://yourdomain.com

# Database
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=loyalty_system
DB_USERNAME=root
DB_PASSWORD=

# Stripe
STRIPE_KEY=pk_live_51ABC...
STRIPE_SECRET=sk_live_51ABC...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_STARTER_PRICE_ID=price_1ABC...
STRIPE_PROFESSIONAL_PRICE_ID=price_1DEF...
STRIPE_ENTERPRISE_PRICE_ID=price_1GHI...

# Firebase
FIREBASE_PROJECT_ID=loyalty-system-xxxxx
FIREBASE_SERVER_KEY=AAAA...
FIREBASE_DATABASE_URL=https://loyalty-system-xxxxx.firebaseio.com
FIREBASE_CREDENTIALS=storage/app/firebase-credentials.json

# Twilio
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_FROM_NUMBER=+14155551234
TWILIO_VERIFY_SID=VAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# SendGrid
SENDGRID_API_KEY=SG.xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SENDGRID_FROM_EMAIL=noreply@yourdomain.com
SENDGRID_FROM_NAME=Loyalty System
```

---

## Testing

### Test Stripe Integration

```php
// In Tinker or a test route
use App\Services\StripeService;
use App\Models\Tenant;

$stripe = new StripeService();
$tenant = Tenant::first();

// Create test subscription
$subscription = $stripe->createSubscription($tenant, 'starter');

dd($subscription);
```

### Test Firebase Notifications

```php
use App\Services\FirebaseService;

$firebase = new FirebaseService();

$result = $firebase->sendPointsEarnedNotification(
    'test_device_token_here',
    50,
    'Test Business',
    'en'
);

dd($result);
```

### Test Twilio OTP

```php
use App\Services\TwilioService;

$twilio = new TwilioService();

// Send OTP
$sent = $twilio->sendOtp('+962791234567');
dd('OTP sent:', $sent);

// Verify OTP
$valid = $twilio->verifyOtp('+962791234567', '123456');
dd('OTP valid:', $valid);
```

### Test SendGrid Email

```php
use App\Services\SendGridService;

$sendgrid = new SendGridService();

$sent = $sendgrid->sendWelcomeEmail(
    'test@example.com',
    'Test User',
    'Test Business',
    100
);

dd('Email sent:', $sent);
```

---

## Production Checklist

### Before Going Live

#### Stripe
- [ ] Switch from test mode to live mode
- [ ] Update API keys to live keys
- [ ] Test webhook endpoint with live mode
- [ ] Set up proper error monitoring
- [ ] Configure tax rates if applicable
- [ ] Set up billing alerts

#### Firebase
- [ ] Remove test devices
- [ ] Set up proper security rules
- [ ] Configure Firebase Authentication (optional)
- [ ] Monitor quota usage
- [ ] Set up Cloud Functions for automation

#### Twilio
- [ ] Upgrade from trial account
- [ ] Verify production phone number
- [ ] Enable international SMS if needed
- [ ] Set up usage alerts
- [ ] Configure message templates

#### SendGrid
- [ ] Verify domain authentication
- [ ] Set up DKIM and SPF records
- [ ] Create production email templates
- [ ] Test email deliverability
- [ ] Monitor sender reputation

---

## Troubleshooting

### Stripe Issues

**Subscription creation fails:**
- Check API keys are correct
- Verify payment method is valid
- Check Stripe logs in Dashboard
- Ensure customer has valid email

**Webhooks not working:**
- Verify webhook URL is accessible
- Check webhook signing secret
- View webhook logs in Stripe Dashboard
- Ensure middleware doesn't block requests

### Firebase Issues

**Notifications not received:**
- Check device token is valid
- Verify server key is correct
- Check device has internet connection
- Ensure app has notification permissions
- View FCM logs in Firebase Console

### Twilio Issues

**OTP not received:**
- Verify phone number format (+country code)
- Check account balance
- Verify Verify Service SID is correct
- Check Twilio logs for delivery status
- Ensure phone number can receive SMS

**SMS rate limited:**
- Twilio Verify has built-in rate limiting
- Wait before sending another OTP
- Check Verify Service settings

### SendGrid Issues

**Emails not delivered:**
- Check email is not in spam folder
- Verify sender identity is authenticated
- Check SendGrid activity feed
- Ensure recipient email is valid
- Check for bounce/block lists

**Emails look broken:**
- Test HTML rendering
- Use email testing tools (Litmus, Email on Acid)
- Ensure proper HTML structure
- Test on multiple email clients

---

## Cost Estimates

### Monthly Costs (Approximate)

**Stripe:**
- 2.9% + $0.30 per successful charge
- No monthly fee
- Example: 100 subscriptions × $29 = $29 revenue - $87 fees = profit

**Firebase:**
- Free tier: 10GB storage, 50GB bandwidth, 20K writes/day
- Blaze plan: Pay-as-you-go
- Estimated: $5-25/month for 1000 active users

**Twilio:**
- OTP via Verify: $0.05 per verification
- SMS: $0.0075 per message
- Estimated: $50-100/month for 1000 verifications

**SendGrid:**
- Free tier: 100 emails/day
- Essentials: $19.95/month for 50,000 emails
- Pro: $89.95/month for 100,000 emails
- Estimated: $20-90/month depending on volume

**Total Monthly Cost (estimated):** $75-215/month for moderate usage

---

## Support & Resources

### Official Documentation
- **Stripe:** [https://stripe.com/docs](https://stripe.com/docs)
- **Firebase:** [https://firebase.google.com/docs](https://firebase.google.com/docs)
- **Twilio:** [https://www.twilio.com/docs](https://www.twilio.com/docs)
- **SendGrid:** [https://docs.sendgrid.com](https://docs.sendgrid.com)

### SDKs Used
- Stripe PHP SDK: `stripe/stripe-php`
- Firebase Admin SDK: Custom HTTP client
- Twilio PHP SDK: `twilio/sdk`
- SendGrid PHP SDK: `sendgrid/sendgrid`

---

**Last Updated:** November 29, 2025
**Status:** All integrations implemented and ready for configuration
